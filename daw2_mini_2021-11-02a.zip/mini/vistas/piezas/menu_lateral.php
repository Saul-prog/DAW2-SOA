<?php 
//Pieza de generación del "menu izquierdo"...

?>
<div class="menu">
<ul>
<li><a href="?a=inicio">Inicio</a></li>
<li><a href="?a=clientes">Clientes</a></li>
<li><a href="?a=articulos">Articulos</a></li>
<li><a href="?a=pedidos">Pedidos</a></li>
</ul>
</div>