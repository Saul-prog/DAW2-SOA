<h1>PORTADA</h1>
<img src="./recursos/principal.jpg" alt="Poseidon" style="width:600px;height:600px;">
<?php


?>
<?php


