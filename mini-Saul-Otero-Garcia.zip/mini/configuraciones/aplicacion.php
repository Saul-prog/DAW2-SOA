<?php
//Configuración del Sistema actualizada el 2022-11-19 20:52:04
return array (
  'aplicacion.controlador.defecto' => 'catalogo',
  'bd.servidor' => 'localhost',
  'bd.usuario' => 'root',
  'bd.clave' => '',
  'bd.nombre' => 'daw_tienda',
  'bd.charset' => 'utf8',
  'bd.depurar' => false,
  'pagina.lineas' => 10,
  'catalogo.lineas' => 9,
  'ofertas.lineas' => 12,
);
