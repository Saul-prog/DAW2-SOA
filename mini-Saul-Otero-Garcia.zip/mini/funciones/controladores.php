<?php
//Un sistema basico de gestion de controladores
//(c) DAW2 - EPSZ - Univ. Salamanca
class controlador
{
  //-------------------------------------------------------------------------
  //Atributo con la accion predeterminada si no se indica en la petición.
  public $accion_defecto= 'inicio';
  
  //-------------------------------------------------------------------------
  //Crear una URL relativa al controlador activo.
  /*public static function url_accion( $accion, $params=null)
  {
    aplicacion::url_accion( $params);
    
    
    aplicacion::url_recurso( $recurso)
    {
    }//url_recurso
    
    $url= '?'.http_build_query( array('a'=>'catalogo.add', 'ref'=>$articulo->referencia, 'p'=>$pagina));
  }//url_accion
  */
  
  //-------------------------------------------------------------------------
  
  //-------------------------------------------------------------------------
  //-------------------------------------------------------------------------

}//class controlador