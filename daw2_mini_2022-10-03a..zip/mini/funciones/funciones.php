<?php
require_once( 'errores.php');
require_once( 'configuracion.php');
require_once( 'depuracion.php');
require_once( 'sesiones.php');
require_once( 'permisos.php');
require_once( 'controladores.php');
require_once( 'vistas.php');
require_once( 'modelos.php');
require_once( 'aplicacion.php');
