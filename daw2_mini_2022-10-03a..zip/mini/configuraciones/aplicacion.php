<?php
//Configuración del Sistema actualizada el 2021-10-05 18:56:56
return array (
  'aplicacion.controlador.defecto' => 'catalogo',
  'bd.servidor' => 'localhost',
  'bd.usuario' => 'root',
  'bd.clave' => '',
  'bd.nombre' => 'daw_tienda',
  'bd.charset' => 'utf8',
  'bd.depurar' => false,
  'pagina.lineas' => 10,
  'catalogo.lineas' => 9,
);
